#!/bin/sh

. ./env.sh 

$JBOSS_HOME/bin/jdr.sh $@
