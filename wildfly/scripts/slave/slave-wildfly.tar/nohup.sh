#!/bin/sh

. ./env.sh 

tail -f $SERVER_NAME.out
